
using Microsoft.AspNetCore.Mvc;
using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;

namespace ABCRetailAzureProject.Controllers
{
    public class StorageController : Controller
    {
        private string conn = "DefaultEndpointsProtocol=https;AccountName=st10499815storage;AccountKey=s6enXLxnK0o2VTRL0b04ncWE90rhdo1lM7jpaoSN6g5Nq245FfpW4ZNFRmznjIr3bD5qad9zEqtf+AStml7OzA==;EndpointSuffix=core.windows.net";

        [HttpPost]
        public async Task<IActionResult> AddTable(string name)
        {
            var table = new TableClient(conn, "Customers");
            await table.CreateIfNotExistsAsync();

            var entity = new TableEntity("cust", Guid.NewGuid().ToString())
            {
                { "Name", name }
            };

            await table.AddEntityAsync(entity);
            return RedirectToAction("Index","Home");
        }

        [HttpPost]
        public async Task<IActionResult> UploadBlob(IFormFile file)
        {
            var container = new BlobContainerClient(conn, "images");
            await container.CreateIfNotExistsAsync();
            var blob = container.GetBlobClient(file.FileName);
            await blob.UploadAsync(file.OpenReadStream(), true);
            return RedirectToAction("Index","Home");
        }

        [HttpPost]
        public async Task<IActionResult> AddQueue(string message)
        {
            var queue = new QueueClient(conn, "orders");
            await queue.CreateIfNotExistsAsync();
            await queue.SendMessageAsync(message);
            return RedirectToAction("Index","Home");
        }

        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            var share = new ShareClient(conn, "logs");
            await share.CreateIfNotExistsAsync();
            var root = share.GetRootDirectoryClient();
            var f = root.GetFileClient(file.FileName);
            await f.CreateAsync(file.Length);
            await f.UploadAsync(file.OpenReadStream());
            return RedirectToAction("Index","Home");
        }
    }
}
