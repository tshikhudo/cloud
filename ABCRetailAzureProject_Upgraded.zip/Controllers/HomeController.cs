
using Microsoft.AspNetCore.Mvc;
using Azure.Data.Tables;

namespace ABCRetailAzureProject.Controllers
{
    public class HomeController : Controller
    {
        private string conn = "DefaultEndpointsProtocol=https;AccountName=st10499815storage;AccountKey=s6enXLxnK0o2VTRL0b04ncWE90rhdo1lM7jpaoSN6g5Nq245FfpW4ZNFRmznjIr3bD5qad9zEqtf+AStml7OzA==;EndpointSuffix=core.windows.net";

        public async Task<IActionResult> Index()
        {
            var table = new TableClient(conn, "Customers");
            await table.CreateIfNotExistsAsync();
            var customers = table.QueryAsync<TableEntity>();
            List<string> names = new();

            await foreach (var c in customers)
            {
                if (c.ContainsKey("Name"))
                    names.Add(c["Name"].ToString());
            }

            return View(names);
        }
    }
}
